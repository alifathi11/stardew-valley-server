package org.example.controller.NPC;

public enum Direction {
    UP,
    DOWN,
    LEFT,
    RIGHT,
    ;
}
