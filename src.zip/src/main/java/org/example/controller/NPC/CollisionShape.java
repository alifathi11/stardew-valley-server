package org.example.controller.NPC;

public enum CollisionShape {
    RECTANGLE,
    ELLIPSE,
    POLYGON,
    POLYLINE,
    ;
}
