package org.example.controller.NPC;

public enum NPCState {
    IDLE,
    WALKING,
}
