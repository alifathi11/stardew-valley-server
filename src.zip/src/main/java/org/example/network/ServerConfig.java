package org.example.network;

public class ServerConfig {
    private int port;

    public ServerConfig(int port) {
        this.port = port;
    }

    public int getPort() {
        return port;
    }
}
