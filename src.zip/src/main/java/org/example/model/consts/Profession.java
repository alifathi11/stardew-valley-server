package org.example.model.consts;

public enum Profession {
    LAZY_BUM,
    BLACK_SMITH,
    FARMER,
    RANCHER,
    FISHERMAN,
    BARISTA,
    PET_SELLER,
    WOOD_SELLER,
    ;
}
