package org.example.model.consts;

public enum LobbyState {
    WAITING,
    IN_GAME,
    CANCELED,
    ;
}
