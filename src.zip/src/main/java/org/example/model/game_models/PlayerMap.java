package org.example.model.game_models;

public class PlayerMap {
    private final Tile[][] map;

    public PlayerMap(Tile[][] map) {
        this.map = map;
    }
}
