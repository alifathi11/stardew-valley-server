package org.example.model.game_models;

public class Wallet {
    private int coin;

    public Wallet(int coin) {
        this.coin = coin;
    }

    public int getCoin() {
        return coin;
    }

    public void setCoin(int coin) {
        this.coin = coin;
    }
}
